# mosip_esignet — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), OpenAI Codex / AGENTS.md (2026-04), Claude Code (2026-06), Cursor (2026-06)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 1311 |
| commit | 76 |
| issue_opened | 1 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 1311 |
| Cursor | commit | 57 |
| OpenAI Codex / AGENTS.md | commit | 11 |
| Claude Code | commit | 8 |
| CodeRabbit | issue_opened | 1 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 61.70 | 49.82 | -11.88 ↓ | 10/11 |
| mean monthly lines added | 19412.30 | 26630.73 | 7218.43 ↑ | 10/11 |
| mean monthly lines removed | 8419.90 | 28018.91 | 19599.01 ↑ | 10/11 |
| mean monthly contributors | 14.50 | 13.91 | -0.59 ↓ | 10/11 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 802.224 | 1379.594 | 577.370 ↑ | 10/10 |
| bugs | -2.061 | 3.364 | 5.424 ↑ | 10/10 |
| vulnerabilities | -0.376 | 2.473 | 2.848 ↑ | 10/10 |
| code smells | 14.921 | 32.079 | 17.158 ↑ | 10/10 |
| cognitive complexity | 67.285 | 162.442 | 95.158 ↑ | 10/10 |
| technical debt (remediation min) | 124.436 | 129.964 | 5.527 ↑ | 10/10 |
| duplication % | -0.373 | -0.061 | 0.312 ↑ | 10/10 |
| comment density % | -0.098 | 0.013 | 0.112 ↑ | 10/10 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 921.9 | n/a | 0/5 |
| mean monthly issues opened | 0.2 | 42.8 | 42.7 ↑ | 6/11 |
| mean open bug backlog | 0.0 | 64.2 | 64.2 ↑ | 6/11 |

**Whole-repo issue statistics:**

- total=472 · open=314 · closed=158 · close-rate=0.335
- resolution: p25=8.1d · median=22.0d · p75=37.6d · p90=59.8d · mean=26.3d
- first response: median=331.75h · p90=1164.36h
- bugs=221 (open 148) · AI-authored issues=1 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.414 | 0.414 ↑ | 10/11 |
| mean monthly PRs opened | 42.1 | 48.1 | 6.0 ↑ | 10/11 |
| median review comments/PR | 0.0 | 1.5 | 1.5 ↑ | 10/11 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

