# mosip_resident-services — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), OpenAI Codex / AGENTS.md (2026-06), Claude Code (2026-06)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 109 |
| commit | 4 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 109 |
| OpenAI Codex / AGENTS.md | commit | 2 |
| Claude Code | commit | 2 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 24.11 | 15.09 | -9.02 ↓ | 9/11 |
| mean monthly lines added | 26019.11 | 2085.00 | -23934.11 ↓ | 9/11 |
| mean monthly lines removed | 1101.89 | 767.55 | -334.34 ↓ | 9/11 |
| mean monthly contributors | 6.22 | 4.82 | -1.40 ↓ | 9/11 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 77.036 | 103.500 | 26.464 ↑ | 7/11 |
| bugs | -0.018 | 0.000 | 0.018 ↑ | 7/11 |
| vulnerabilities | 0.000 | 0.000 | 0.000 → | 7/11 |
| code smells | 0.714 | -6.691 | -7.405 ↓ | 7/11 |
| cognitive complexity | 1.000 | 0.573 | -0.427 ↓ | 7/11 |
| technical debt (remediation min) | 21.161 | -270.036 | -291.197 ↓ | 7/11 |
| duplication % | 0.012 | -0.072 | -0.084 ↓ | 7/11 |
| comment density % | -0.000 | 0.016 | 0.016 ↑ | 7/11 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 1913.8† | n/a | 0/2 |
| mean monthly issues opened | n/a | 5.1 | n/a | 0/9 |
| mean open bug backlog | n/a | 16.4 | n/a | 0/9 |

> ⚠ **Underpowered (†)** — fewer than 3 months of data behind median resolution (hours) (post n=2). Read those as indicative only, not as a trend.

**Whole-repo issue statistics:**

- total=46 · open=41 · closed=5 · close-rate=0.109
- resolution: p25=69.9d · median=89.0d · p75=90.1d · p90=138.8d · mean=87.8d
- first response: median=1225.3h · p90=2161.32h
- bugs=33 (open 31) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.240 | 0.240 ↑ | 10/11 |
| mean monthly PRs opened | 12.4 | 10.0 | -2.4 ↓ | 10/11 |
| median review comments/PR | 0.0 | 0.3 | 0.3 ↑ | 10/11 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

