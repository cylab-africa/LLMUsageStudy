# mosip_packet-manager — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), OpenAI Codex / AGENTS.md (2026-06), Cursor (2026-08)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 54 |
| commit | 2 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 54 |
| OpenAI Codex / AGENTS.md | commit | 1 |
| Cursor | commit | 1 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 8.75 | 10.89 | 2.14 ↑ | 8/9 |
| mean monthly lines added | 541.25 | 1773.56 | 1232.31 ↑ | 8/9 |
| mean monthly lines removed | 208.75 | 521.44 | 312.69 ↑ | 8/9 |
| mean monthly contributors | 4.38 | 4.11 | -0.26 ↓ | 8/9 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 132.663 | 150.919 | 18.256 ↑ | 7/7 |
| bugs | 0.000 | 0.146 | 0.146 ↑ | 7/7 |
| vulnerabilities | 0.000 | 0.000 | 0.000 → | 7/7 |
| code smells | 11.072 | 9.794 | -1.278 ↓ | 7/7 |
| cognitive complexity | 2.395 | 20.523 | 18.128 ↑ | 7/7 |
| technical debt (remediation min) | 64.638 | 97.570 | 32.932 ↑ | 7/7 |
| duplication % | 0.044 | 0.179 | 0.134 ↑ | 7/7 |
| comment density % | 0.039 | 0.063 | 0.024 ↑ | 7/7 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 137.0† | n/a | 0/1 |
| mean monthly issues opened | n/a | 2.0† | n/a | 0/1 |
| mean open bug backlog | n/a | 0.0† | n/a | 0/1 |

> ⚠ **Underpowered (†)** — fewer than 3 months of data behind all metrics (post n=1). Read those as indicative only, not as a trend.

**Whole-repo issue statistics:**

- total=2 · open=1 · closed=1 · close-rate=0.5
- resolution: p25=5.7d · median=5.7d · p75=5.7d · p90=5.7d · mean=5.7d
- first response: median=n/ah · p90=n/ah
- bugs=0 (open 0) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.289 | 0.289 ↑ | 9/9 |
| mean monthly PRs opened | 6.5 | 8.8 | 2.3 ↑ | 10/10 |
| median review comments/PR | 0.2 | 0.5 | 0.3 ↑ | 9/9 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

