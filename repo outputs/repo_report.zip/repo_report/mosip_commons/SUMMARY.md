# mosip_commons — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), Claude Code (2026-05), OpenAI Codex / AGENTS.md (2026-06)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 51 |
| commit | 4 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 51 |
| OpenAI Codex / AGENTS.md | commit | 3 |
| Claude Code | commit | 1 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 25.00 | 17.56 | -7.44 ↓ | 9/9 |
| mean monthly lines added | 5175.56 | 3348.33 | -1827.22 ↓ | 9/9 |
| mean monthly lines removed | 5477.33 | 2122.00 | -3355.33 ↓ | 9/9 |
| mean monthly contributors | 6.22 | 5.89 | -0.33 ↓ | 9/9 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | -1046.027 | 70.985 | 1117.013 ↑ | 6/8 |
| bugs | 0.000 | 0.824 | 0.824 ↑ | 6/8 |
| vulnerabilities | -0.122 | 0.000 | 0.122 ↑ | 6/8 |
| code smells | -16.450 | 0.118 | 16.567 ↑ | 6/8 |
| cognitive complexity | -26.040 | 12.471 | 38.510 ↑ | 6/8 |
| technical debt (remediation min) | -127.754 | 2.000 | 129.754 ↑ | 6/8 |
| duplication % | -0.036 | 0.024 | 0.060 ↑ | 6/8 |
| comment density % | 0.273 | 0.113 | -0.160 ↓ | 6/8 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 695.7 | n/a | 0/4 |
| mean monthly issues opened | n/a | 1.9 | n/a | 0/7 |
| mean open bug backlog | n/a | 0.4 | n/a | 0/7 |

**Whole-repo issue statistics:**

- total=13 · open=9 · closed=4 · close-rate=0.308
- resolution: p25=6.9d · median=43.0d · p75=43.0d · p90=64.2d · mean=29.0d
- first response: median=1417.34h · p90=1613.97h
- bugs=1 (open 1) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.272 | 0.272 ↑ | 10/9 |
| mean monthly PRs opened | 13.2 | 12.0 | -1.2 ↓ | 10/10 |
| median review comments/PR | 0.2 | 0.3 | 0.1 ↑ | 10/10 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

