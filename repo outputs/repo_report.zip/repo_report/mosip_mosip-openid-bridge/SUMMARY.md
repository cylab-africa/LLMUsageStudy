# mosip_mosip-openid-bridge — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), Claude Code (2026-06), OpenAI Codex / AGENTS.md (2026-06)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 9 |
| commit | 4 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 9 |
| Claude Code | commit | 2 |
| OpenAI Codex / AGENTS.md | commit | 2 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 7.33 | 12.86 | 5.52 ↑ | 9/7 |
| mean monthly lines added | 500.67 | 867.00 | 366.33 ↑ | 9/7 |
| mean monthly lines removed | 269.44 | 319.57 | 50.13 ↑ | 9/7 |
| mean monthly contributors | 3.33 | 4.43 | 1.10 ↑ | 9/7 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 1.767 | 30.752 | 28.984 ↑ | 5/5 |
| bugs | 0.000 | 0.000 | 0.000 → | 5/5 |
| vulnerabilities | 0.000 | 0.000 | 0.000 → | 5/5 |
| code smells | -0.442 | 0.134 | 0.576 ↑ | 5/5 |
| cognitive complexity | 0.628 | 6.688 | 6.060 ↑ | 5/5 |
| technical debt (remediation min) | -2.209 | -3.210 | -1.001 ↓ | 5/5 |
| duplication % | 0.000 | -0.040 | -0.040 ↓ | 5/5 |
| comment density % | 0.000 | 0.013 | 0.013 ↑ | 5/5 |

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.139 | 0.139 ↑ | 9/6 |
| mean monthly PRs opened | 5.0 | 6.6 | 1.6 ↑ | 10/10 |
| median review comments/PR | 0.6 | 0.1 | -0.5 ↓ | 9/8 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

