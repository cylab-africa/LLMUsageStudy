# mosip_pre-registration — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), OpenAI Codex / AGENTS.md (2026-06)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 152 |
| commit | 1 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 152 |
| OpenAI Codex / AGENTS.md | commit | 1 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 10.60 | 15.62 | 5.03 ↑ | 10/8 |
| mean monthly lines added | 3490.20 | 1796.50 | -1693.70 ↓ | 10/8 |
| mean monthly lines removed | 745.40 | 572.75 | -172.65 ↓ | 10/8 |
| mean monthly contributors | 5.90 | 4.88 | -1.03 ↓ | 10/8 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 118.566 | 283.350 | 164.784 ↑ | 8/8 |
| bugs | 0.316 | 0.000 | -0.316 ↓ | 8/8 |
| vulnerabilities | 0.000 | 0.000 | 0.000 → | 8/8 |
| code smells | 16.519 | -1.638 | -18.157 ↓ | 8/8 |
| cognitive complexity | 1.033 | 26.264 | 25.232 ↑ | 8/8 |
| technical debt (remediation min) | 104.123 | -153.485 | -257.608 ↓ | 8/8 |
| duplication % | 0.014 | -0.030 | -0.044 ↓ | 8/8 |
| comment density % | -0.098 | -0.014 | 0.084 ↑ | 8/8 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | n/a | n/a | 0/0 |
| mean monthly issues opened | n/a | 2.0 | n/a | 0/4 |
| mean open bug backlog | n/a | 4.0 | n/a | 0/4 |

**Whole-repo issue statistics:**

- total=8 · open=8 · closed=0 · close-rate=0.0
- resolution: p25=n/a · median=n/a · p75=n/a · p90=n/a · mean=n/a
- first response: median=n/ah · p90=n/ah
- bugs=4 (open 4) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.444 | 0.444 ↑ | 10/9 |
| mean monthly PRs opened | 15.9 | 11.1 | -4.8 ↓ | 10/10 |
| median review comments/PR | 0.0 | 3.5 | 3.5 ↑ | 10/10 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

