# mosip_nfiq — AI-impact evaluation

**AI-adoption month (split point): `2025-12`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-12), OpenAI Codex / AGENTS.md (2026-08)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 6 |
| commit | 3 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 6 |
| OpenAI Codex / AGENTS.md | commit | 3 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 5.00 | 12.25 | 7.25 ↑ | 5/4 |
| mean monthly lines added | 7549.00 | 5947.25 | -1601.75 ↓ | 5/4 |
| mean monthly lines removed | 176.60 | 52.25 | -124.35 ↓ | 5/4 |
| mean monthly contributors | 2.00 | 4.50 | 2.50 ↑ | 5/4 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 2587.842 | 3.500 | -2584.342 ↓ | 3/3 |
| bugs | 1.684 | 0.000 | -1.684 ↓ | 3/3 |
| vulnerabilities | 0.842 | 0.000 | -0.842 ↓ | 3/3 |
| code smells | 29.684 | 0.000 | -29.684 ↓ | 3/3 |
| cognitive complexity | 95.579 | 0.000 | -95.579 ↓ | 3/3 |
| technical debt (remediation min) | 145.474 | 0.538 | -144.935 ↓ | 3/3 |
| duplication % | 1.200 | 0.013 | -1.187 ↓ | 3/3 |
| comment density % | -2.232 | 0.000 | 2.232 ↑ | 3/3 |

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.163 | 0.163 ↑ | 5/4 |
| mean monthly PRs opened | 2.5 | 2.8 | 0.3 ↑ | 8/9 |
| median review comments/PR | 0.0 | 2.2 | 2.2 ↑ | 6/4 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

