# mosip_id-authentication — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), Claude Code (2026-06), OpenAI Codex / AGENTS.md (2026-06)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 125 |
| commit | 5 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 125 |
| OpenAI Codex / AGENTS.md | commit | 3 |
| Claude Code | commit | 2 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 22.70 | 14.30 | -8.40 ↓ | 10/10 |
| mean monthly lines added | 16946.50 | 7967.90 | -8978.60 ↓ | 10/10 |
| mean monthly lines removed | 4438.80 | 2464.20 | -1974.60 ↓ | 10/10 |
| mean monthly contributors | 8.70 | 6.30 | -2.40 ↓ | 10/10 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | -80.137 | 355.873 | 436.009 ↑ | 9/10 |
| bugs | -0.099 | 0.000 | 0.099 ↑ | 9/10 |
| vulnerabilities | -0.147 | 0.000 | 0.147 ↑ | 9/10 |
| code smells | -0.882 | -4.836 | -3.954 ↓ | 9/10 |
| cognitive complexity | -1.362 | 23.267 | 24.628 ↑ | 9/10 |
| technical debt (remediation min) | 99.524 | -284.418 | -383.942 ↓ | 9/10 |
| duplication % | 0.011 | -0.120 | -0.131 ↓ | 9/10 |
| comment density % | -0.010 | -0.033 | -0.023 ↓ | 9/10 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 50.5† | n/a | 0/2 |
| mean monthly issues opened | 0.1 | 3.2 | 3.1 ↑ | 7/10 |
| mean open bug backlog | 0.0 | 8.0 | 8.0 ↑ | 7/10 |

> ⚠ **Underpowered (†)** — fewer than 3 months of data behind median resolution (hours) (post n=2). Read those as indicative only, not as a trend.

**Whole-repo issue statistics:**

- total=33 · open=31 · closed=2 · close-rate=0.061
- resolution: p25=1.9d · median=1.9d · p75=2.3d · p90=2.3d · mean=2.1d
- first response: median=31.03h · p90=31.03h
- bugs=16 (open 16) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.286 | 0.286 ↑ | 10/11 |
| mean monthly PRs opened | 20.7 | 13.4 | -7.3 ↓ | 10/11 |
| median review comments/PR | 0.0 | 0.6 | 0.6 ↑ | 10/11 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

