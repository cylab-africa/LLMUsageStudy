# mosip_keymanager — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), Claude Code (2026-06), OpenAI Codex / AGENTS.md (2026-06)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 73 |
| commit | 4 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 73 |
| Claude Code | commit | 2 |
| OpenAI Codex / AGENTS.md | commit | 2 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 9.40 | 15.70 | 6.30 ↑ | 10/10 |
| mean monthly lines added | 2104.40 | 4297.40 | 2193.00 ↑ | 10/10 |
| mean monthly lines removed | 381.50 | 1372.40 | 990.90 ↑ | 10/10 |
| mean monthly contributors | 3.10 | 4.80 | 1.70 ↑ | 10/10 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 634.176 | 232.119 | -402.057 ↓ | 9/7 |
| bugs | 0.143 | 1.164 | 1.020 ↑ | 9/7 |
| vulnerabilities | 0.072 | 0.248 | 0.177 ↑ | 9/7 |
| code smells | 18.451 | 6.147 | -12.304 ↓ | 9/7 |
| cognitive complexity | 52.388 | 25.223 | -27.165 ↓ | 9/7 |
| technical debt (remediation min) | 106.476 | 71.101 | -35.375 ↓ | 9/7 |
| duplication % | 0.261 | -0.081 | -0.342 ↓ | 9/7 |
| comment density % | -0.236 | -0.029 | 0.208 ↑ | 9/7 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 343.6 | n/a | 0/3 |
| mean monthly issues opened | 0.2 | 0.8 | 0.5 ↑ | 4/9 |
| mean open bug backlog | 0.0 | 0.0 | 0.0 → | 4/9 |

**Whole-repo issue statistics:**

- total=8 · open=4 · closed=4 · close-rate=0.5
- resolution: p25=1.9d · median=7.8d · p75=7.8d · p90=34.2d · mean=11.0d
- first response: median=163.22h · p90=476.62h
- bugs=0 (open 0) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.288 | 0.288 ↑ | 10/10 |
| mean monthly PRs opened | 10.9 | 13.9 | 3.0 ↑ | 10/10 |
| median review comments/PR | 0.0 | 1.1 | 1.1 ↑ | 10/10 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

