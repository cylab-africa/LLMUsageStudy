# mosip_registration — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), Claude Code (2026-03), OpenAI Codex / AGENTS.md (2026-06)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 183 |
| commit | 6 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 183 |
| Claude Code | commit | 4 |
| CodeRabbit | commit | 1 |
| OpenAI Codex / AGENTS.md | commit | 1 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 19.00 | 20.00 | 1.00 ↑ | 10/10 |
| mean monthly lines added | 6472.60 | 9749.30 | 3276.70 ↑ | 10/10 |
| mean monthly lines removed | 2345.30 | 4680.30 | 2335.00 ↑ | 10/10 |
| mean monthly contributors | 6.30 | 6.90 | 0.60 ↑ | 10/10 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 158.945 | 349.406 | 190.460 ↑ | 10/8 |
| bugs | 0.000 | 0.189 | 0.189 ↑ | 10/8 |
| vulnerabilities | 0.000 | 0.000 | 0.000 → | 10/8 |
| code smells | 2.358 | 5.638 | 3.281 ↑ | 10/8 |
| cognitive complexity | 11.012 | 41.755 | 30.743 ↑ | 10/8 |
| technical debt (remediation min) | 21.903 | 68.365 | 46.462 ↑ | 10/8 |
| duplication % | 0.015 | 0.043 | 0.028 ↑ | 10/8 |
| comment density % | -0.042 | -0.011 | 0.031 ↑ | 10/8 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 2342.3 | n/a | 0/4 |
| mean monthly issues opened | 1.0† | 3.9 | 2.9 ↑ | 1/10 |
| mean open bug backlog | 0.0† | 7.7 | 7.7 ↑ | 1/10 |

> ⚠ **Underpowered (†)** — fewer than 3 months of data behind mean monthly issues opened, mean open bug backlog (pre n=1). Read those as indicative only, not as a trend.

**Whole-repo issue statistics:**

- total=40 · open=35 · closed=5 · close-rate=0.125
- resolution: p25=5.7d · median=12.1d · p75=123.1d · p90=252.4d · mean=78.6d
- first response: median=337.79h · p90=1632.04h
- bugs=18 (open 17) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.303 | 0.303 ↑ | 10/10 |
| mean monthly PRs opened | 25.2 | 14.5 | -10.7 ↓ | 10/11 |
| median review comments/PR | 0.0 | 0.3 | 0.3 ↑ | 10/11 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

