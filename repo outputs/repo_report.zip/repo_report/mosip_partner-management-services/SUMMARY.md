# mosip_partner-management-services — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), Claude Code (2026-05), OpenAI Codex / AGENTS.md (2026-08)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 681 |
| commit | 4 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 681 |
| Claude Code | commit | 3 |
| OpenAI Codex / AGENTS.md | commit | 1 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 48.50 | 22.55 | -25.95 ↓ | 10/11 |
| mean monthly lines added | 34994.00 | 24545.27 | -10448.73 ↓ | 10/11 |
| mean monthly lines removed | 12873.70 | 3121.36 | -9752.34 ↓ | 10/11 |
| mean monthly contributors | 9.20 | 5.45 | -3.75 ↓ | 10/11 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 1765.061 | 881.891 | -883.170 ↓ | 10/10 |
| bugs | 0.000 | -0.145 | -0.145 ↓ | 10/10 |
| vulnerabilities | 0.000 | 0.000 | 0.000 → | 10/10 |
| code smells | 44.164 | 15.776 | -28.388 ↓ | 10/10 |
| cognitive complexity | 121.248 | 50.503 | -70.745 ↓ | 10/10 |
| technical debt (remediation min) | 564.406 | -135.733 | -700.139 ↓ | 10/10 |
| duplication % | 0.012 | -0.182 | -0.194 ↓ | 10/10 |
| comment density % | -0.113 | -0.044 | 0.069 ↑ | 10/10 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 867.4 | n/a | 0/4 |
| mean monthly issues opened | n/a | 27.6 | n/a | 0/7 |
| mean open bug backlog | n/a | 34.1 | n/a | 0/7 |

**Whole-repo issue statistics:**

- total=193 · open=125 · closed=68 · close-rate=0.352
- resolution: p25=24.1d · median=37.9d · p75=55.5d · p90=81.1d · mean=44.1d
- first response: median=402.31h · p90=1263.95h
- bugs=46 (open 40) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.387 | 0.387 ↑ | 10/11 |
| mean monthly PRs opened | 50.4 | 24.7 | -25.7 ↓ | 10/11 |
| median review comments/PR | 0.0 | 1.0 | 1.0 ↑ | 10/11 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

