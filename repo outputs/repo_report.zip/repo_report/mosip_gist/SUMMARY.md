# mosip_gist — AI-impact evaluation

**No AI usage detected** (no attributable commit, merge, PR, review, or issue) — there is no adoption split, so every table below reports a single whole-history column rather than a before/after comparison.


## 1. Velocity (speed)

| Metric | whole history | n months |
|---|--:|--:|
| mean monthly commits | 1.00† | 1 |
| mean monthly lines added | 21.00† | 1 |
| mean monthly lines removed | 0.00† | 1 |
| mean monthly contributors | 1.00† | 1 |

> ⚠ **Underpowered (†)** — fewer than 3 months of data behind all metrics (n=1). Read those as indicative only, not as a trend.

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | whole-history slope | n months |
|---|--:|--:|
| size (ncloc) | n/a | 0 |
| bugs | n/a | 0 |
| vulnerabilities | n/a | 0 |
| code smells | n/a | 0 |
| cognitive complexity | n/a | 0 |
| technical debt (remediation min) | n/a | 0 |
| duplication % | n/a | 0 |
| comment density % | n/a | 0 |

## 4. Code-review automation

**AI review bots detected:** NONE

| Metric | whole history | n months |
|---|--:|--:|
| mean AI-review share | n/a | 0 |
| mean monthly PRs opened | 2.0† | 1 |
| median review comments/PR | 0.0† | 1 |

> ⚠ **Underpowered (†)** — fewer than 3 months of data behind mean monthly PRs opened, median review comments/PR (n=1). Read those as indicative only, not as a trend.

## Interpretation


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

