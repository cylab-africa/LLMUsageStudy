# mosip_android-registration-client — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), OpenAI Codex / AGENTS.md (2026-08)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 615 |
| commit | 2 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 615 |
| OpenAI Codex / AGENTS.md | commit | 2 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 8.50 | 12.09 | 3.59 ↑ | 10/11 |
| mean monthly lines added | 5754.20 | 11050.27 | 5296.07 ↑ | 10/11 |
| mean monthly lines removed | 1930.80 | 4703.18 | 2772.38 ↑ | 10/11 |
| mean monthly contributors | 3.30 | 3.55 | 0.25 ↑ | 10/11 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 2446.655 | 1311.485 | -1135.170 ↓ | 10/10 |
| bugs | 3.927 | 1.818 | -2.109 ↓ | 10/10 |
| vulnerabilities | 1.430 | 0.133 | -1.297 ↓ | 10/10 |
| code smells | 247.352 | 35.539 | -211.812 ↓ | 10/10 |
| cognitive complexity | 61.467 | 218.655 | 157.188 ↑ | 10/10 |
| technical debt (remediation min) | 2860.861 | 536.364 | -2324.497 ↓ | 10/10 |
| duplication % | -1.170 | 0.154 | 1.324 ↑ | 10/10 |
| comment density % | 0.202 | 0.005 | -0.196 ↓ | 10/10 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 497.7 | n/a | 0/3 |
| mean monthly issues opened | n/a | 37.7 | n/a | 0/9 |
| mean open bug backlog | n/a | 90.7 | n/a | 0/9 |

**Whole-repo issue statistics:**

- total=339 · open=335 · closed=4 · close-rate=0.012
- resolution: p25=9.2d · median=26.2d · p75=26.2d · p90=62.8d · mean=24.6d
- first response: median=227.66h · p90=2014.51h
- bugs=167 (open 166) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.381 | 0.381 ↑ | 10/11 |
| mean monthly PRs opened | 10.1 | 15.5 | 5.4 ↑ | 10/11 |
| median review comments/PR | 0.3 | 6.4 | 6.1 ↑ | 10/11 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

