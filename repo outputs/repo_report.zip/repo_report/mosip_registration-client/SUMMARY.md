# mosip_registration-client — AI-impact evaluation

**AI-adoption month (split point): `2025-12`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-12), OpenAI Codex / AGENTS.md (2026-04)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 138 |
| commit | 2 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 138 |
| OpenAI Codex / AGENTS.md | commit | 2 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 5.57 | 5.00 | -0.57 ↓ | 7/8 |
| mean monthly lines added | 90.00 | 2148.88 | 2058.88 ↑ | 7/8 |
| mean monthly lines removed | 86.86 | 417.12 | 330.27 ↑ | 7/8 |
| mean monthly contributors | 2.86 | 2.50 | -0.36 ↓ | 7/8 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | -0.724 | 838.298 | 839.022 ↑ | 4/8 |
| bugs | 0.000 | 2.774 | 2.774 ↑ | 4/8 |
| vulnerabilities | 0.000 | 2.440 | 2.440 ↑ | 4/8 |
| code smells | -0.071 | 54.536 | 54.607 ↑ | 4/8 |
| cognitive complexity | 0.000 | 66.619 | 66.619 ↑ | 4/8 |
| technical debt (remediation min) | -0.357 | 482.131 | 482.488 ↑ | 4/8 |
| duplication % | 0.000 | -0.073 | -0.073 ↓ | 4/8 |
| comment density % | -0.000 | -0.054 | -0.054 ↓ | 4/8 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 602.1† | n/a | 0/1 |
| mean monthly issues opened | 0.2 | 2.8 | 2.5 ↑ | 4/10 |
| mean open bug backlog | 0.0 | 4.9 | 4.9 ↑ | 4/10 |

> ⚠ **Underpowered (†)** — fewer than 3 months of data behind median resolution (hours) (post n=1). Read those as indicative only, not as a trend.

**Whole-repo issue statistics:**

- total=29 · open=26 · closed=3 · close-rate=0.103
- resolution: p25=0.0d · median=25.1d · p75=25.1d · p90=25.1d · mean=16.7d
- first response: median=225.47h · p90=467.39h
- bugs=10 (open 10) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.465 | 0.465 ↑ | 9/10 |
| mean monthly PRs opened | 5.1 | 6.3 | 1.2 ↑ | 11/10 |
| median review comments/PR | 0.2 | 7.4 | 7.2 ↑ | 9/10 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

