# mosip_bio-utils — AI-impact evaluation

**AI-adoption month (split point): `2025-12`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-12), OpenAI Codex / AGENTS.md (2026-06)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 26 |
| commit | 1 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 26 |
| OpenAI Codex / AGENTS.md | commit | 1 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 17.00 | 17.60 | 0.60 ↑ | 6/5 |
| mean monthly lines added | 5909.33 | 6944.40 | 1035.07 ↑ | 6/5 |
| mean monthly lines removed | 1243.17 | 345.20 | -897.97 ↓ | 6/5 |
| mean monthly contributors | 4.33 | 3.40 | -0.93 ↓ | 6/5 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 5339.200 | 2.366 | -5336.834 ↓ | 4/5 |
| bugs | 3.600 | 0.000 | -3.600 ↓ | 4/5 |
| vulnerabilities | 0.000 | 0.000 | 0.000 → | 4/5 |
| code smells | 44.300 | 0.139 | -44.161 ↓ | 4/5 |
| cognitive complexity | 52.700 | 0.278 | -52.422 ↓ | 4/5 |
| technical debt (remediation min) | 598.900 | 0.974 | -597.926 ↓ | 4/5 |
| duplication % | 0.040 | 0.000 | -0.040 ↓ | 4/5 |
| comment density % | 0.160 | 0.000 | -0.160 ↓ | 4/5 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 147.2† | n/a | 0/1 |
| mean monthly issues opened | n/a | 1.0† | n/a | 0/1 |
| mean open bug backlog | n/a | 0.0† | n/a | 0/1 |

> ⚠ **Underpowered (†)** — fewer than 3 months of data behind all metrics (post n=1). Read those as indicative only, not as a trend.

**Whole-repo issue statistics:**

- total=1 · open=0 · closed=1 · close-rate=1.0
- resolution: p25=6.1d · median=6.1d · p75=6.1d · p90=6.1d · mean=6.1d
- first response: median=n/ah · p90=n/ah
- bugs=0 (open 0) · AI-authored issues=0 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.223 | 0.223 ↑ | 6/5 |
| mean monthly PRs opened | 5.5 | 5.4 | -0.2 ↓ | 11/8 |
| median review comments/PR | 0.0 | 1.2 | 1.2 ↑ | 7/4 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

