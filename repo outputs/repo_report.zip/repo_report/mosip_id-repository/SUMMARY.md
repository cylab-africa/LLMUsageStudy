# mosip_id-repository — AI-impact evaluation

**AI-adoption month (split point): `2025-11`** — defined as the *first trackable AI action of any kind* (commit, merge, push, PR open/merge, review, or issue), not the first config file.

Per-agent first action: CodeRabbit (2025-11), Claude Code (2026-05), OpenAI Codex / AGENTS.md (2026-06), Cursor (2026-08)


## 0. AI operations detected (what did AI actually do?)

Counts of AI-attributed actions across **all branches**, by operation type. `commit`=authored, `merge`/`pr_merged`=integrated, `push`=applied by an agent identity, `pr_opened`/`pr_reviewed`/`issue_*`=platform actions.

| Operation | count |
|---|--:|
| pr_reviewed | 179 |
| commit | 17 |
| issue_opened | 2 |

By agent × operation:

| Agent | operation | count |
|---|---|--:|
| CodeRabbit | pr_reviewed | 179 |
| OpenAI Codex / AGENTS.md | commit | 7 |
| Cursor | commit | 6 |
| Claude Code | commit | 4 |
| CodeRabbit | issue_opened | 2 |

## 1. Velocity (speed)

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean monthly commits | 57.70 | 23.10 | -34.60 ↓ | 10/10 |
| mean monthly lines added | 18645.30 | 11189.90 | -7455.40 ↓ | 10/10 |
| mean monthly lines removed | 4274.50 | 7065.20 | 2790.70 ↑ | 10/10 |
| mean monthly contributors | 11.60 | 7.70 | -3.90 ↓ | 10/10 |

## 2. Code size & quality (SonarQube, monthly snapshots)

Quality is reported as **trend slope** (change per calendar month): positive slope on smells/bugs/debt = worsening. Months missing from the series count as elapsed time, not as one step.

| Metric | pre-slope | post-slope | Δ slope | n months (pre/post) |
|---|--:|--:|--:|--:|
| size (ncloc) | 246.079 | 412.782 | 166.703 ↑ | 10/10 |
| bugs | 0.048 | 0.000 | -0.048 ↓ | 10/10 |
| vulnerabilities | 0.000 | -0.255 | -0.255 ↓ | 10/10 |
| code smells | 7.273 | 2.255 | -5.018 ↓ | 10/10 |
| cognitive complexity | -0.061 | -21.521 | -21.461 ↓ | 10/10 |
| technical debt (remediation min) | 39.630 | -174.079 | -213.709 ↓ | 10/10 |
| duplication % | 0.207 | -0.185 | -0.392 ↓ | 10/10 |
| comment density % | -0.056 | 0.116 | 0.172 ↑ | 10/10 |

## 3. Issue-resolution health

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| median resolution (hours) | n/a | 2.1† | n/a | 0/2 |
| mean monthly issues opened | n/a | 4.6 | n/a | 0/5 |
| mean open bug backlog | n/a | 7.2 | n/a | 0/5 |

> ⚠ **Underpowered (†)** — fewer than 3 months of data behind median resolution (hours) (post n=2). Read those as indicative only, not as a trend.

**Whole-repo issue statistics:**

- total=23 · open=19 · closed=4 · close-rate=0.174
- resolution: p25=0.0d · median=0.2d · p75=0.2d · p90=5.7d · mean=1.5d
- first response: median=0.14h · p90=0.14h
- bugs=9 (open 9) · AI-authored issues=2 · AI-closed issues=0

## 4. Code-review automation

**AI review bots detected:** CodeRabbit

| Metric | pre | post | Δ | n months (pre/post) |
|---|--:|--:|--:|--:|
| mean AI-review share | 0.000 | 0.242 | 0.242 ↑ | 10/10 |
| mean monthly PRs opened | 25.1 | 20.6 | -4.5 ↓ | 10/11 |
| median review comments/PR | 0.0 | 0.0 | 0.0 → | 10/11 |

## Interpretation

Read §1 (velocity) against §2 (quality slope): the paper's core finding is *velocity rises but complexity/debt slope worsens after adoption*. Compare the Δ columns to see whether this repo follows that pattern or not.


> **Caveat — single repo, descriptive only.** This is a before/after comparison, not a causal effect. Confounds (project maturity, contributor influx, release cycles) are not controlled here. A causal estimate requires many AI-adopting repos vs matched controls fed to the study's DiD / panel notebooks — the per-repo CSVs in this folder are schema-compatible for exactly that scale-up.


## Appendix — what the SonarQube metrics mean

| Metric | Type | Plain-English meaning | Direction |
|---|---|---|---|
| `ncloc` | size | Non-comment lines of code — logic size, excluding blanks/comments. | neutral (context) |
| `bugs` | reliability | Code SonarQube judges demonstrably wrong — will misbehave at runtime. | lower = better |
| `vulnerabilities` | security | Security weaknesses (e.g. hard-coded secrets, injection). | lower = better |
| `code_smells` | maintainability | Working but poorly-structured code (dupes, long methods, dead code). Not bugs — maintainability debt. | lower = better |
| `cognitive_complexity` | maintainability | How hard the code is for a human to follow (nesting, branching). Rises even at constant size. | lower = better |
| `technical_debt` | maintainability | Estimated minutes to fix all code smells (SonarQube 'remediation effort'). | lower = better |
| `duplicated_lines_density` | maintainability | % of lines that are copy-pasted duplicates. | lower = better |
| `comment_lines_density` | documentation | Comments as % of (code + comments). Very low or very high can both be smells. | context |

*In §2, each metric is shown as a **slope** (change per calendar month, gaps in the monthly series included). A positive slope on smells/complexity/debt means quality is degrading over time; the pre-vs-post Δ shows whether AI adoption changed that rate. Raw counts rise with `ncloc`, so also read them per-1k-lines when comparing periods of different size. The `n months` column is the sample behind each figure; a † marks fewer than 3 months.*

